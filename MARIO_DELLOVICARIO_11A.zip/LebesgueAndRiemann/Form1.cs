﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LebesgueAndRiemann
{
    public partial class Form1 : Form
    {

        int lowerBoundOfInterval;
        int upperBoundOfInterval;
        decimal dx = 1;
        int m = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void lebesgueIntegral()
        {
            decimal x;
            decimal y = m * upperBoundOfInterval;
            decimal area = 0;

            while (y > 0)
            {
                x = y / m;
                area = area + ((upperBoundOfInterval - x) * dx);
                y = y - dx;
            }
            this.richTextBox1.AppendText(area.ToString());
        }

        private void riemannIntegral()
        {
            decimal x = lowerBoundOfInterval;
            decimal y;
            decimal area = 0;
            while (x < upperBoundOfInterval)
            {
                y = m * x;
                area = area + (y * dx);
                x = x + dx;
            }
            this.richTextBox2.AppendText(area.ToString());
        }

        private void divisionButton_Click(object sender, EventArgs e)
        {
            dx = dx / 2;
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            dx = 1;
            m = 0;
            this.richTextBox1.Clear();
            this.richTextBox2.Clear();
            this.mTextBox.Clear();
            this.lowerBoundTextBox.Clear();
            this.upperBoundTextBox.Clear();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            m = int.Parse(this.mTextBox.Text);
            lowerBoundOfInterval = int.Parse(this.lowerBoundTextBox.Text);
            upperBoundOfInterval = int.Parse(this.upperBoundTextBox.Text);
            riemannIntegral();
            lebesgueIntegral();
        }
    }
}
